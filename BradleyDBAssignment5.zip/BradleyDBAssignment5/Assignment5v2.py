#-------------------------------------------------#
# Title: <Assignment 5 - Todo List>
# Dev:   <bbazhaw>
# Date:  <10-29-2016>
# Desc: <Reads data from a text file to a dict, displays info to user then asks for user input>
# ChangeLog: (Who, When, What)
# <>
#-------------------------------------------------#

#-- Data -- #
dicttodo={}#my empty dict set
dicttable=[]#add the new “row” into a Python List object
task= None #will ask user for this later
priority = None #will ask user for this later
userdict={}#storing my inputs from the user
choice = None #stole this idea from the geek dictionary!



#-- Processing --#

def Text_Display():
    todofile = open("Todo.txt","r")#open the text file in read mode
    for line in todofile: #for loop so I can go through as many rows as there are
        key=line.strip().split()[0]#
        value=line.strip().split()[1]
        dicttodo[key]=value
    #dicttable.append(dicttodo)
    return dicttodo #Display the contents of the List to the user.
    todofile.close()#closing the connection
#-- Presentation --#

print("Welcome to your To Do List! Here is what you have so far: ")
print(Text_Display())
todofile = open("Todo.txt","a")#open the text file in wright mode
# Allow the user to Add or Remove tasks from the list using numbered choices. Something like this would work:
print("Now you have some options. Please select from the following: \n")
print ("Press 1 to Add task and priority level")
print ("Press 2 to Remove a task and priority level")
print ("Press 3 to Save all tasks to the Todo.txt file and exit!")
while choice !=3:
    while True:
        try:
            choice = int(input("Your Choice: "))
            break #if int is found we move on to assigning the name_value variable
        except ValueError: #if anything but an int is input I print an error message instead of having my code break
            print("Please try again with a numeral '1', '2, or '3'")#I'll tell you what I want, what I really really want
    if choice == 1:
        task = input("\nPlease add your task: ")
        priority = input("\nWhat Priority is this?: ")
        dicttodo[task]=priority#storing my inputs from the user
        dicttable.append(dicttodo)
    elif choice == 2:
        task = input("\nWhich Task do you want to delete?: ")
        if task in dicttable:
            dicttable.__delitem__(task)
    elif choice == 3:
        todofile.write(str(dicttable))
        todofile.close()
todofile.close()
print(dicttable)


